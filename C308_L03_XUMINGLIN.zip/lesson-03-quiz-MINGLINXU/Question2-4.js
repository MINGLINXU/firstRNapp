//Question 2

class Vehicle{
    constructor(model,wheels){
        this._model = model;
        this._wheels = wheels;

    }
    makeSound(){
        console.log("Vroom Vroom");
    }
}

class car extends Vehicle{
    constructor(model,wheels){
        super(model);
        this.wheels = 4;
    }
}

//Question3
// let name = "Loretta", job="Engineer", nationality = "Thai";

var obj = (name,job,nationality) => {
    console.log("Hi! my name is "+name +". I'm a "+job)
}

var output = obj("Loretta", "Engineer", "Thai");

//#Question 4
var employee = ["Kasih Wu", "Shakti Gadhavi"];
employee.shift();
employee.push("Annisa Zheng");
console.log(employee);